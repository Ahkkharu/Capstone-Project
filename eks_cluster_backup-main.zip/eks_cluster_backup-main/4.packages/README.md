### set the backend running the command:
```
source ../scripts/setenv.sh 
```

### initialize terraform to pick up all module configurations

```
terraform init
```

### apply the configurations


```
terraform apply  --var-file ../0.configurations_setup/terraform.tfvars --auto-approve
```

### to push to our registry 

### Pushing docker image
#### Step1: Login to registry
```
docker login -u AWS -p $(aws ecr get-login-password --region the-region-you-are-in) xxxxxxxxx.dkr.ecr.the-region-you-are-in.amazonaws.com
```

# Test push 
```
sudo docker pull wordpress
sudo docker image tag wordpress 715072217548.dkr.ecr.us-east-1.amazonaws.com/artemis:1.0.3
sudo docker push 715072217548.dkr.ecr.us-east-1.amazonaws.com/artemis:1.0.3
```


### Build and push artemis app

# Steps to Build and image and push
# Clone a repo
# git@github.com:farrukh90/artemis.git (the developer code with the Dockerfile)

# Step 1 
#    Change the branch (prior to this we will scan the image for vulnerabilities)
#        git checkout 2.0.0

# Step 2
#    Build Image and tag 
#       sudo docker build -t 715072217548.dkr.ecr.us-east-1.amazonaws.com/artemis:1.0.4 . 

# Step 3 
#    Push the image 
#       sudo docker push 715072217548.dkr.ecr.us-east-1.amazonaws.com/artemis:1.0.4 