#$/bin/bash

aws ecr get-login-password --region us-east-1 | docker login --username AWS --password-stdin 715072217548.dkr.ecr.us-east-1.amazonaws.com
# docker build -t pedro-registry .
# docker tag pedro-registry:latest 715072217548.dkr.ecr.us-east-1.amazonaws.com/pedro-registry:latest
# docker push 715072217548.dkr.ecr.us-east-1.amazonaws.com/pedro-registry:latest