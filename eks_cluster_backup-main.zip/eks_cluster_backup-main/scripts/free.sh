#!/bin/bash
INDEX=2
while [  $INDEX -ge 1 ]
do
free -h
sleep 2
((INDEX++))
done
